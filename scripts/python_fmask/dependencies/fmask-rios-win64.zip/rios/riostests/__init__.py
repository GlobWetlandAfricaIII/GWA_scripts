"""
Contains the tests used to check the RIOS install.

Called from testrios.py in the bin directory
"""

